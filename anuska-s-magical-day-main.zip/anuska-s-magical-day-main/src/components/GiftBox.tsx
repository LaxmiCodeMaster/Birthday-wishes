
import React, { useState, useEffect } from 'react';
import { Gift } from 'lucide-react';

interface GiftBoxProps {
  onOpen: () => void;
}

const GiftBox: React.FC<GiftBoxProps> = ({ onOpen }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  const handleOpen = () => {
    if (isOpen) return;
    
    setIsOpen(true);
    setShowConfetti(true);
    
    // Call the parent onOpen handler after animation delay
    setTimeout(() => {
      onOpen();
    }, 500);
  };

  return (
    <div className="relative">
      {showConfetti && <ConfettiEffect />}
      <div 
        className={`gift-box flex flex-col items-center cursor-pointer ${isOpen ? 'gift-opened' : 'animate-gift-bounce'}`}
        onClick={handleOpen}
      >
        {!isOpen ? (
          <>
            <div className="relative">
              <div className="w-40 h-12 bg-soft-pink rounded-md mb-1 relative overflow-hidden gift-lid">
                <div className="absolute inset-0 bg-gradient-to-r from-soft-pink via-soft-purple to-soft-gold opacity-70"></div>
                <div className="w-6 h-6 bg-soft-gold rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
              </div>
              <div className="w-36 h-36 bg-soft-purple rounded-md relative overflow-hidden flex items-center justify-center">
                <div className="absolute inset-0 bg-gradient-to-br from-soft-purple via-soft-pink to-soft-gold opacity-50"></div>
                <div className="w-full h-full absolute">
                  <div className="absolute top-0 bottom-0 left-1/2 w-1 bg-soft-gold transform -translate-x-1/2"></div>
                  <div className="absolute left-0 right-0 top-1/2 h-1 bg-soft-gold transform -translate-y-1/2"></div>
                </div>
                <Gift className="w-16 h-16 text-soft-gold animate-pulse-glow" />
              </div>
            </div>
            <p className="mt-4 font-handwritten text-xl text-center">Click to open!</p>
          </>
        ) : (
          <div className="animate-gift-open">
            <Gift className="w-32 h-32 text-soft-pink" />
          </div>
        )}
      </div>
    </div>
  );
};

const ConfettiEffect = () => {
  const confettiCount = 100;
  const colors = ['#FFDEE2', '#E5DEFF', '#FDE1D3', '#F8D568', '#FFA69E'];
  
  // Generate random confetti pieces
  const confettiPieces = Array.from({ length: confettiCount }).map((_, i) => {
    const left = `${Math.random() * 100}%`;
    const animationDuration = `${Math.random() * 3 + 2}s`;
    const animationDelay = `${Math.random() * 0.5}s`;
    const color = colors[Math.floor(Math.random() * colors.length)];
    
    return (
      <div
        key={i}
        className="confetti animate-confetti-fall"
        style={{
          left,
          backgroundColor: color,
          animationDuration,
          animationDelay,
          width: `${Math.random() * 10 + 5}px`,
          height: `${Math.random() * 10 + 5}px`,
        }}
      />
    );
  });

  return <div className="confetti-container">{confettiPieces}</div>;
};

export default GiftBox;
