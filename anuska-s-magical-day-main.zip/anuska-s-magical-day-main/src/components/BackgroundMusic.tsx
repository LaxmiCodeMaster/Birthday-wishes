
import React, { useEffect, useRef, useState } from 'react';
import { Music, Play, Pause } from 'lucide-react';

const BackgroundMusic: React.FC = () => {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const togglePlay = () => {
    if (!audioRef.current) return;
    
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(err => {
        console.error("Error playing audio:", err);
      });
    }
    
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <button 
        onClick={togglePlay}
        className="bg-white/80 hover:bg-white text-soft-purple p-3 rounded-full shadow-md flex items-center justify-center backdrop-blur-sm transition-all"
        aria-label={isPlaying ? "Pause music" : "Play music"}
      >
        {isPlaying ? (
          <Pause className="w-5 h-5" />
        ) : (
          <Play className="w-5 h-5" />
        )}
      </button>
      <audio 
        ref={audioRef}
        loop
        src="https://cdn.pixabay.com/download/audio/2022/01/18/audio_3775e85c0b.mp3?filename=happy-birthday-music-box-version-118684.mp3" 
      />
    </div>
  );
};

export default BackgroundMusic;
