
import React from 'react';
import { cn } from '@/lib/utils';

interface PhotoCardProps {
  src: string;
  alt: string;
  caption: string;
  className?: string;
  delay?: number;
}

const PhotoCard: React.FC<PhotoCardProps> = ({ src, alt, caption, className, delay = 0 }) => {
  const delayClass = delay === 1 ? 'animate-fade-in-delay-1' : 
                   delay === 2 ? 'animate-fade-in-delay-2' : 
                   delay === 3 ? 'animate-fade-in-delay-3' : 'animate-fade-in';
  
  return (
    <div className={cn(
      "photo-card bg-white rounded-lg overflow-hidden opacity-0", 
      delayClass,
      className
    )}>
      <div className="aspect-[4/3] overflow-hidden">
        <img 
          src={src} 
          alt={alt}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110" 
        />
      </div>
      <div className="p-4">
        <p className="font-handwritten text-lg text-center text-gray-700">{caption}</p>
      </div>
    </div>
  );
};

export default PhotoCard;
