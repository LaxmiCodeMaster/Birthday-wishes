
import React, { useState, useRef, useEffect } from "react";
import GiftBox from "@/components/GiftBox";
import PhotoCard from "@/components/PhotoCard";
import BackgroundMusic from "@/components/BackgroundMusic";
import { Star, Heart } from "lucide-react";

const Index = () => {
  const [isGiftOpen, setIsGiftOpen] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  const handleGiftOpen = () => {
    setIsGiftOpen(true);
    setTimeout(() => {
      contentRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 500);
  };

  // Generate animated stars
  const renderStars = (count: number) => {
    return Array.from({ length: count }).map((_, i) => {
      const randomX = Math.random() * 100;
      const randomY = Math.random() * 100;
      const size = Math.random() * 15 + 10;
      const animationDelay = Math.random() * 5;
      
      return (
        <div 
          key={i} 
          className="absolute animate-float" 
          style={{
            left: `${randomX}%`,
            top: `${randomY}%`,
            animationDelay: `${animationDelay}s`,
            zIndex: 1
          }}
        >
          {Math.random() > 0.5 ? (
            <Star className="text-soft-gold opacity-30" style={{ width: size, height: size }} />
          ) : (
            <Heart className="text-soft-pink opacity-30" style={{ width: size, height: size }} />
          )}
        </div>
      );
    });
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-pastel-gradient">
      {/* Background decorations */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        {renderStars(20)}
      </div>
      
      {/* Background music control */}
      <BackgroundMusic />
      
      {/* Hero section with gift */}
      <section className="min-h-screen flex flex-col items-center justify-center relative px-4">
        <h1 className="font-handwritten text-4xl md:text-6xl mb-8 text-center text-purple-900 animate-fade-in">
          <span className="block">A Special Surprise</span>
          <span className="block">For Anuska</span>
        </h1>
        
        <GiftBox onOpen={handleGiftOpen} />
      </section>
      
      {/* Birthday content - revealed after gift opens */}
      <div 
        ref={contentRef} 
        className={`transition-opacity duration-1000 ${isGiftOpen ? 'opacity-100' : 'opacity-0'}`}
      >
        {/* Birthday message */}
        <section className="py-16 px-4 flex flex-col items-center">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-handwritten text-5xl md:text-7xl text-center mb-6 bg-gradient-to-r from-pink-500 via-purple-500 to-amber-500 text-transparent bg-clip-text animate-pulse-glow">
              Happy Birthday Anuska!
            </h2>
            
            <div className="bg-white/70 backdrop-blur-sm rounded-xl p-6 md:p-8 shadow-lg">
              <p className="text-xl md:text-2xl mb-6 text-gray-700 leading-relaxed">
                On your special day, I wanted to create something as unique and wonderful as our friendship. 
                Here's to celebrating you and all the beautiful memories we've shared together!
              </p>
              
              <p className="font-handwritten text-2xl text-purple-700">
                With love, Laxmi
              </p>
            </div>
          </div>
        </section>
        
        {/* Photo memories section */}
        <section className="py-16 px-4 bg-white/30">
          <div className="max-w-6xl mx-auto">
            <h2 className="font-handwritten text-4xl md:text-5xl text-center mb-12 text-purple-800">
              Our Favorite Memories
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <PhotoCard 
                src="/lovable-uploads/d66478a8-f391-4874-905d-ba980f59f24b.png" 
                alt="Anuska and friends celebrating Holi" 
                caption="That colorful Holi celebration we'll never forget!" 
                delay={1}
              />
              
              <PhotoCard 
                src="/lovable-uploads/e3ddd3cc-e4dc-4676-8402-45db2e877b5b.png" 
                alt="Anuska with friends during Holi" 
                caption="Always smiling, always making memories" 
                delay={2}
              />
              
              <PhotoCard 
                src="/lovable-uploads/fc5d9a79-563a-4560-bad0-8a5e9c16c1d0.png" 
                alt="Illustrated version of friends" 
                caption="Friends who make life colorful" 
                delay={3}
              />
            </div>
          </div>
        </section>
        
        {/* Personal note section */}
        <section className="py-16 px-4">
          <div className="max-w-3xl mx-auto">
            <div className="bg-white/70 backdrop-blur-sm rounded-xl p-6 md:p-8 shadow-lg">
              <h2 className="font-handwritten text-3xl md:text-4xl text-center mb-6 text-purple-800">
                A Note From Me
              </h2>
              
              <div className="prose prose-lg mx-auto text-gray-700">
                <p>
                  Dear Anuska,
                </p>
                <p>
                  From our crazy Holi celebrations to late night talks, every moment with you has been special. 
                  You've been such an amazing friend through all our ups and downs. Your smile brightens the 
                  darkest days, and your laughter is truly contagious.
                </p>
                <p>
                  Thank you for being the incredible person you are. Here's to many more years of friendship, 
                  adventure, and creating beautiful memories together.
                </p>
                <p>
                  May this year bring you all the happiness, success, and joy that you deserve.
                </p>
                <p className="font-handwritten text-2xl text-purple-700">
                  With love and best wishes,<br />
                  Laxmi
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Footer */}
        <footer className="py-8 text-center text-gray-600 bg-white/50">
          <p className="font-handwritten text-xl">Made with ❤️ for Anuska's special day</p>
        </footer>
      </div>
    </div>
  );
};

export default Index;
